<?php
/**
 *
 * Core
 *
 *
 * @author Rascals Themes
 * @version 1.0.1
 * @category Core
 * @package Toolkit Core
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}